from django.apps import AppConfig


class SpotifysearchConfig(AppConfig):
    name = 'spotifysearch'
